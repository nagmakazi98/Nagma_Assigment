#!/bin/bash

file="test-results.xml"

python3 assessment/xmlAssesment.py assessment/final_assessment_instructions.json $file