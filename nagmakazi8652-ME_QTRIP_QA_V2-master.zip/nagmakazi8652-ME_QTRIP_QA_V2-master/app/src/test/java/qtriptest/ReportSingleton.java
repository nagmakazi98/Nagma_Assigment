package qtriptest;

public class ReportSingleton {
}