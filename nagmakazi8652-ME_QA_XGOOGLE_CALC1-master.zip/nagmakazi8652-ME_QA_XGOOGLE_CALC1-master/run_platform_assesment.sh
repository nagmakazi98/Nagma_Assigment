python3 assesment/remoteAssesment.py assesment/AIS_MO_01.json

